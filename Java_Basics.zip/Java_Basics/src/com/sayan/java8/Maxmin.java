package com.sayan.java8;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Maxmin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range : ");
		int range = sc.nextInt();
		List<Integer> l1 = new ArrayList<Integer>();
		System.out.println("Enter the Elements : ");
		for(int i = 0;i<range;i++)
		{
			int num = sc.nextInt();
			l1.add(num);
		}
		int max = l1.stream().max(Comparator.naturalOrder()).get();
		System.out.println("Max = " + max);
		int min = l1.stream().min(Comparator.naturalOrder()).get();
		System.out.println("Min = " + min);
		sc.close();
	}
}


