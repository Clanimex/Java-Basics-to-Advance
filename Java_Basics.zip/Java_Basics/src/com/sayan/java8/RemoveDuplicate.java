package com.sayan.java8;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class RemoveDuplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range : ");
		int range = sc.nextInt();
		System.out.println("Enter the elements : ");
		List<Integer> l1 = new ArrayList<>();
		for (int i = 0; i < range; i++) {
			int num = sc.nextInt();
			l1.add(num);
		}
		System.out.println("List before change : " + l1);
		List<Integer> lnew = l1.stream().distinct().collect(Collectors.toList());
		System.out.println(lnew);
		sc.close();
	}
	

}
