package com.sayan.java8;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

public class DuplicateELement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int range = sc.nextInt();
		List<Integer> l1 = new ArrayList<Integer>();
		for(int i = 0;i<range;i++)
		{
			int num = sc.nextInt();
			l1.add(num);
		}
		Set<Integer> l2 = new HashSet<Integer>();
		System.out.println(l2);
		Set<Integer> l3 = l1.stream().filter(i->!l2.add(i)).collect(Collectors.toSet());
		System.out.println(l2);
		l1.stream().filter(i->i+1==i).forEach(System.out::println);
		System.out.println(l3);
	}

}
