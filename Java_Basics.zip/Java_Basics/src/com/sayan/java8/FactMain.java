package com.sayan.java8;

public class FactMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FactorsCheck f1 = (n,d)->(n%d)==0;
		if(f1.test(10, 2))
		{
			System.out.println("2 is a factor of 10");
		}
		if(!f1.test(10, 3))
			System.out.println("3 is not a factor of 10");
	}

}
