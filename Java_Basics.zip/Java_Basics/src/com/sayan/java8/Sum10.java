package com.sayan.java8;

import java.util.stream.IntStream;

public class Sum10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum = IntStream.range(1, 11).sum();
		System.out.println(sum);

	}

}
