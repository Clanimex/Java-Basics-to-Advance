package com.sayan.java8;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StartNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		List<String> l1 = new ArrayList<String>();
		System.out.println("Enter the range : ");
		int range = sc.nextInt();
		System.out.println("Enter the Elements : ");
		for (int i = 0; i < range; i++) {
			String st = sc.next();
			l1.add(st);
		}
		System.out.println("The WORDS are listed below : ");
		l1.stream().filter(str -> Character.isDigit(str.charAt(0))).forEach(System.out::println);

	}

}
