package com.sayan.java8;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Max3_Min3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range : ");
		int range = sc.nextInt();
		List<Integer> l1 = new ArrayList<Integer>();
		System.out.println("Enter the elemests : ");
		for (int i = 0; i < range; i++) {
			int num = sc.nextInt();
			l1.add(num);
		}
		System.out.println("Max : ");
		l1.stream().sorted().limit(3).forEach(System.out::println);
		System.out.println("Min : ");
		l1.stream().sorted(Comparator.reverseOrder()).limit(3).forEach(System.out::println);
		sc.close();
	}

}
