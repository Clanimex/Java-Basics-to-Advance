package com.sayan.java8;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sap1 add = (a,b) -> a + b;
		Sap1 multi = (a,b) -> a*b;
		
		System.out.println(add.operation(6,3));

		System.out.println(multi.operation(6,3));
	}

}
