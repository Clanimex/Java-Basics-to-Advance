package com.sayan.java8;

import java.util.Scanner;

public class CheckAlpha {
	public static boolean alpa(String str) {
		return ((str != null) && (!str.equals("")) && (str.chars().allMatch(Character::isLetter)));
			
		
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your String : ");
		String st = sc.nextLine();
		System.out.println("Result is : " + alpa(st));
		sc.close();
	}
}
