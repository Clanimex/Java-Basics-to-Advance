package com.sayan.java8;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class SecondLargest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range : ");
		int range = sc.nextInt();
		List<Integer> l1 = new ArrayList<Integer>();
		System.out.println("Enter the elements : ");
		for(int i = 0;i<range;i++)
		{
			int num = sc.nextInt();
			l1.add(num);
		}
		int sec = l1.stream().sorted(Comparator.reverseOrder()).skip(1).findFirst().get();
		System.out.println("The Second Largest number : " + sec);
		sc.close();
	}

}
