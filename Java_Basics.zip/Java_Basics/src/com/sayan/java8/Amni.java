package com.sayan.java8;

interface Parent{
	default void sayHello() {
		System.out.println("Hello");
	}
}
//@FunctionalInterface
class Child implements Parent{

	@Override
	public void sayHello() {
		// TODO Auto-generated method stub
		System.out.println("Child says hello");
	}
	
}
public class Amni {
		// TODO Auto-generated method stub
		public static void main(String args[])
		{
			Child c = new Child();
			c.sayHello();
		}
}

