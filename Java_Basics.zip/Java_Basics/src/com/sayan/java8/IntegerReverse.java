package com.sayan.java8;

import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.IntStream;

public class IntegerReverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range : ");
		int range = sc.nextInt();
		int arr1[] = new int[range];
		for (int i = 0; i < range; i++) {
			arr1[i] = sc.nextInt();
		}
		int rev[] = IntStream.rangeClosed(1, range).map(i -> arr1[range-i]).toArray();
	
	System.out.println("The Vallue is : " + Arrays.toString(rev));}

}
