package com.sayan.java8;

import java.util.Arrays;
import java.util.stream.IntStream;

public class sort1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= new int[] {45,67,42,89,90};
		int b[] = new int[] {1,2,3,4};
		int c[] = IntStream.concat(Arrays.stream(a), Arrays.stream(b)).sorted().toArray();
		System.out.println(Arrays.toString(c));
	}

}
