package com.sayan.java8;

import java.util.Arrays;
import java.util.Scanner;

public class Sum_Average {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range : ");
		int range = sc.nextInt();
		int sum[]= new int[range];
		System.out.println("Enter the elements : ");
		for(int i = 0;i<range;i++) {
			sum[i]=sc.nextInt();
		}
		int add = Arrays.stream(sum).sum();
		System.out.println("SUM = " + add);
		double avg = Arrays.stream(sum).average().getAsDouble();
		System.out.println("Average = " + avg);
	}

}
