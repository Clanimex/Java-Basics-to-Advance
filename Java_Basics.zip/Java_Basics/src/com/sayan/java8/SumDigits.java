package com.sayan.java8;

import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SumDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number : ");
		int i = sc.nextInt();
		int sum = Stream.of(String.valueOf(i).split("")).collect(Collectors.summingInt(Integer :: parseInt));
		System.out.println("The Sum of the digits are : " + sum);
		sc.close();
	}

}
