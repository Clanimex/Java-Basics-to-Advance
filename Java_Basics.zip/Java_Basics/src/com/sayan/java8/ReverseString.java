package com.sayan.java8;

import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Collectors;

public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Word : ");
		String str = sc.nextLine();
		String rev = Arrays.stream(str.split(" ")).map(word -> new StringBuffer(word).reverse())
				.collect(Collectors.joining(" "));
		System.out.println(rev);
		sc.close();
	}

}
