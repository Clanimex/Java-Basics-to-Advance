package com.sayan.java8;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ListWithLamda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range : ");
		int range = sc.nextInt();
		List<Integer> l1 = new ArrayList<Integer>();
		System.out.println("Enter the elements : ");
		for(int i = 1;i<=range;i++)
		{
			int num = sc.nextInt();
			l1.add(num);
		}
		
		System.out.println("Printing all the elements : ");
		l1.forEach(n -> System.out.println(n));
		sc.close();
	}

}
