package com.sayan.java8;

import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Anagrams {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two words : ");
		String st = sc.nextLine();
		String st2 = sc.nextLine();
		String a = Stream.of(st.split("")).map(String :: toUpperCase).sorted().collect(Collectors.joining());
		String b = Stream.of(st2.split("")).map(String::toUpperCase).sorted().collect(Collectors.joining());
		if(a.equals(b))
		{
			System.out.println("They are anagrams" + a +" " + b);
		}
		else {
			System.out.println("They are not anagrams");
		}
	}

}
