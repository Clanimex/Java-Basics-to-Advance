package com.sayan.java8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class LamdaSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> l1 = new ArrayList<Integer>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range : ");
		int range = sc.nextInt();
		System.out.println("Enter the elements : ");
		for(int i=0;i<=range;i++)
		{
			int num = sc.nextInt();
			l1.add(num);
		}
		
		System.out.println("Elements before sorting : " + l1);
		Collections.sort(l1, (a,b)-> (a<b) ? -1 : (a>b) ? 1:0);
		System.out.println("Elements after sorting : " + l1);
		List<Integer> l2 = new ArrayList<>();
		l2=l1;
		Collections.reverse(l2);
		System.out.println("Elements after sorting with normal collections : " + l2);
		sc.close();
	}

}
