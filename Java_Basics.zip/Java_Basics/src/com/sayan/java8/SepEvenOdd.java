package com.sayan.java8;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

public class SepEvenOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range : ");
		int range = sc.nextInt();
		List<Integer> l1 = new ArrayList<>();
		System.out.println("Enter the elements : ");
		for(int i = 0;i<range;i++) {
			int num = sc.nextInt();
			l1.add(num);
		}
		Map<Boolean, List<Integer>> oddmap = l1.stream().collect(Collectors.partitioningBy(i -> i%2==0));
		Set<Entry<Boolean,List<Integer>>> entrySet = oddmap.entrySet();
		
		for(Entry<Boolean, List<Integer>> entry : entrySet)
		{
			if(entry.getKey())
			{
				System.out.println("Even Number");
			}
			else
			{
				System.out.println("Odd Numbers");
			}
			List<Integer> list= entry.getValue();
			for(int i :list)
			{
				System.out.println(i);
			}
		}
		sc.close();
	}

}
