package com.sayan.java8;

import java.util.stream.IntStream;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "CRICKET";
		boolean p = IntStream.range(0, str.length()/2).noneMatch(i->str.charAt(i)!=str.charAt(str.length()-i-1));
		if(p)
		{
			System.out.println(str + " is a palindrome");
		}
		else
		{
			System.out.println(str + " is not a palindrome");
		}
	}

}
