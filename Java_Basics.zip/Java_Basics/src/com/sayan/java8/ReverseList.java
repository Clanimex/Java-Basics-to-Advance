package com.sayan.java8;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class ReverseList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range of the list : ");
		int range = sc .nextInt();
		List<Double> l1 = new ArrayList<Double>();
		System.out.println("Enter the elemets : ");
		for(int i = 0;i <range;i++)
		{
			double num = sc.nextInt();
			l1.add(num);
		}
		System.out.println("Full List : " + l1);
		l1.stream().sorted(Comparator.reverseOrder()).forEach(System.out :: println);
		sc.close();
	}

}
