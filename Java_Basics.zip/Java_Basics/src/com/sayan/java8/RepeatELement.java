package com.sayan.java8;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;

public class RepeatELement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> l1 = Arrays.asList("Sayan","is","a","good","He","belives","in","god's","plan","Keep","shinning","Sayan");
		Map<String, Long> count = l1.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		Entry<String,Long> element = count.entrySet().stream().max(Map.Entry.comparingByValue()).get();
		System.out.println("Most Frequent Element : " + element.getKey());
		System.out.println("Count : " + element.getValue() );
	}

}
