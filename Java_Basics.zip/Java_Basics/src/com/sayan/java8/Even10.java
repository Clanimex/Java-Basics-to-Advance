package com.sayan.java8;

import java.util.stream.IntStream;

public class Even10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IntStream.range(1, 10).map(i -> i * 2).forEach(System.out::println);

	}

}
