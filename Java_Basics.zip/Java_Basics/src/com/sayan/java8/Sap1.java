package com.sayan.java8;

@FunctionalInterface
interface Sap1 {
	int operation(int a, int b);
}
