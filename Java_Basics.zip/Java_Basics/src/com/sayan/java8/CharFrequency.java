package com.sayan.java8;

import java.util.Map;
import java.util.Scanner;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CharFrequency {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a sentence : ");
		String st = sc.nextLine();
		Map<Character, Long> count = st.chars().mapToObj(c -> (char) c).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(count);
		count.forEach((key,value) -> System.out.println(key + " = "  + value));
		sc.close();
	}

}
