package com.sayan.java8;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ElementFreq {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Sentence : ");
		String st = sc.nextLine();
		List<String> l1 = Arrays.asList("Pencil","Rubber","GHUM");
		Map<String, Long> st2 = l1.stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		System.out.println(st2);
		sc.close();
	}

}
