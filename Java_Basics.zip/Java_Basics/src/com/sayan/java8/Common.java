package com.sayan.java8;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Common {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		List<Integer> l1 = Arrays.asList(34,78,98,22,45,90);
		List<Integer> l2 = Arrays.asList(23,78,98,34,67,31);
		l1.stream().filter(l2::contains).forEach(System.out::println);
	}

}
