package com.sayan.java8;

interface FactorsCheck {
	boolean test(int n, int d);

}
