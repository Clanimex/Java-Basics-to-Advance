package com.sayan.java8;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class SortString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range : ");
		int range = sc.nextInt();
		System.out.println("Enter the elements : ");
		List<String> l1 = new ArrayList<String>();
		for(int i = 0;i<range;i++)
		{
			String word = sc.next();
			l1.add(word);
		}
		System.out.println("Total List : " + l1);
		l1.stream().sorted(Comparator.comparing(String :: length)).forEach(System.out::println);
	}

}
