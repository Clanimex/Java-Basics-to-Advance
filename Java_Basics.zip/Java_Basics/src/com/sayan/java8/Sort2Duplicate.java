package com.sayan.java8;

import java.util.Arrays;
import java.util.stream.IntStream;

public class Sort2Duplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = new int[] { 12, 43, 6, 78, 89 };
		int b[] = new int[] { 67, 45, 26, 3, 6, 12, 89, 45 };
		int c[] = IntStream.concat(Arrays.stream(a), Arrays.stream(b)).sorted().distinct().toArray();
		System.out.println(c);//it will give reference id 
		System.out.println(Arrays.toString(c));//it will give actual value
	}

}
