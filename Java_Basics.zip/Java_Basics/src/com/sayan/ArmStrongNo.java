package com.sayan;

import java.util.Scanner;

public class ArmStrongNo {
	void amrs(int n) {
		int temp = n;
		double sum = 0.0;
		while (n != 0) {
			int d = n % 10;
			sum += Math.pow(d, 3);
			n = n / 10;
		}
		if (temp == sum) {
			System.out.println("Its an arsmstrong number : " + sum);
		} else {
			System.out.println("Its not an arsmstrong number : " + temp);
		}
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		ArmStrongNo armStrongNo = new ArmStrongNo();
		System.out.println("Enter a number : ");
		int h = sc.nextInt();
		armStrongNo.amrs(h);
		sc.close();
	}
}
