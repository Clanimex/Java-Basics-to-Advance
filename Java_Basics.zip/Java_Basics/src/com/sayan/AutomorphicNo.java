package com.sayan;

import java.util.Scanner;

public class AutomorphicNo {
	void auto(int n) {
		int temp = n;
		int count = 0;
		while (temp != 0) {
			int d = temp % 10;
			count = count + 1;
			temp = temp / 10;
		}
		int num = 0;
		int d = n * n;
		num = d % (int) (Math.pow(10, count));
		if(num==n)
		{
			System.out.println("Its an Automorphic Number : " + n);
		}
		else
		{
			System.out.println("Its not an Automorphic Number : " + n);
		}
	}
	public static void main(String args[])
	{
		AutomorphicNo automorphicNo = new AutomorphicNo();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a Number : ");
		int number = sc.nextInt();
		automorphicNo.auto(number);
	}
}
