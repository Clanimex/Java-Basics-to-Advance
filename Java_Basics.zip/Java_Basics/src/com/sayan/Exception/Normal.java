package com.sayan.Exception;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Normal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int s = 0;
		List<Integer> l1 = new ArrayList<>();
		System.out.println("Enter the range : ");
		int range = sc.nextInt();
		
		for(int i = 0;i<=range;i++)
		{
			int num=sc.nextInt();
			l1.add(num);
			s = s + l1.get(i);
		}
		try {
			int div = divnum(5,0);
			System.out.println("div : " + div);
		}
		catch(ArithmeticException e) {
			System.out.println("Error is : " + e.getMessage());
		}
		
	}
	public static int divnum(int a,int b) {
		if(b==0)
		{
			throw new  ArithmeticException("Not possible");
		}
		return a/b;
	}

}

