package com.sayan;

import java.util.Scanner;

public class StartEnd {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		char ch1 = ' ', ch2 = ' ';
		System.out.println("Enter a sentence");
		String st = sc.nextLine();
		String[] words = st.split(" ");
		for (int i=0;i<words.length;i++) {
			//System.out.println("check 1");
			ch1 = words[i].charAt(0);
			ch2 = words[i].charAt(words[i].length() - 1);
			//System.out.println("check 2");
			if (ch1 == 'a'|| ch1 == 'e' || ch1 == 'i' || ch1 == 'o' || ch1 == 'u') {
				if(ch2 == 'a' || ch2 == 'e' || ch2 == 'i' || ch2 == 'o' || ch2 == 'u')
				{
					System.out.println(words[i]);
				}
				
			}
		}
		sc.close();
	}

}
