package com.sayan.abstraction;

class Dog extends Animal{
	@Override
	public void animalSound() {
		// TODO Auto-generated method stub
		System.out.println("eeeee Bhow Bhow Clanimex");
		
	}
}
