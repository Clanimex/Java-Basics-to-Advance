package com.sayan.abstraction;

abstract class Animal {
	public abstract void animalSound();
	 public void sound()
	 {
		 System.out.println("Hello Clanimex");
	 }
}
