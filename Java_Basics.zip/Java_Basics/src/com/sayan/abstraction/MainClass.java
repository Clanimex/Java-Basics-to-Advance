package com.sayan.abstraction;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog dog = new Dog();
		dog.animalSound();
		dog.sound();
	}

}
