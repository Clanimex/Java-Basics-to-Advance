package com.sayan.ExtraJava8;

public interface class1 {
	String getdata();

}
