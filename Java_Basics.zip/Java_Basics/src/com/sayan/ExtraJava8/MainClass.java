package com.sayan.ExtraJava8;

public class MainClass  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		class1 c = () -> "Software";
		System.out.println(c.getdata());
	}

}
