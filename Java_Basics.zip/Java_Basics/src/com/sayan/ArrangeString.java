package com.sayan;
//arranging sentence on the basis of the string length
import java.util.Scanner;

public class ArrangeString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String str = " ";
		int minword = 0, min = 0;
		String temp = " ";
		System.out.println("Enter a sentence");
		str = sc.nextLine();
		String[] words = str.split(" ");

		for (int i = 0; i < words.length; i++) {
			minword = words[i].length();
			for (int j = i + 1; j < words.length; j++) {
				int l = words[j].length();
				if (minword > l) {
					min = j;
				}
			}
			temp = words[i];
			words[i] = words[min];
			words[min] = temp;

		}
		for(String w : words)
		{
			System.out.print(w + " ");
		}
		sc.close();
	}

}
