package com.sayan.polymorphism;

public class Main {
	public static void main(String args[]) {
		Vehicle car = new Car();
		Vehicle bike = new Bike();
		vehiclecheck(car);
		vehiclecheck(bike);
	}
	public static void vehiclecheck(Vehicle vehicle)
	{
		vehicle.startEngine();
		vehicle.stopEngine();
		
	}
}
