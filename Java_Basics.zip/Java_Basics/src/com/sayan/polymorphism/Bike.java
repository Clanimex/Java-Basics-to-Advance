package com.sayan.polymorphism;

public class Bike extends Vehicle {

	@Override
	public void startEngine() {
		// TODO Auto-generated method stub
		System.out.println("Bike Starts with Key");

	}

	@Override
	public void stopEngine() {
		// TODO Auto-generated method stub
		System.out.println("Bike Stops with Key");

	}

}
