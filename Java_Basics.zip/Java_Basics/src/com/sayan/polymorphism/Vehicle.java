package com.sayan.polymorphism;

abstract class Vehicle {
	public abstract void startEngine();
	
	public abstract void stopEngine();
}
