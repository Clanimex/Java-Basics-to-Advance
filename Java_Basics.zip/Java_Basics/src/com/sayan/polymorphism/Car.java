package com.sayan.polymorphism;

class Car extends Vehicle{

	@Override
	public void startEngine() {
		// TODO Auto-generated method stub
		System.out.println("Car Starts with Key");
		
	}

	@Override
	public void stopEngine() {
		// TODO Auto-generated method stub
		System.out.println("Car Stops with Key");
	}

}
