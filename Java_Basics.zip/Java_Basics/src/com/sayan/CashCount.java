package com.sayan;

import java.util.Scanner;

public class CashCount {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int lst[]= {500,200,100,50,20,10,5,2,1};
		
		System.out.println("Enter you amount");
		int cash = sc.nextInt();
		for(int i=0;i<lst.length;i++)
		{
			int n = cash/lst[i];
			System.out.println("No. of Notes of "+ lst[i] + " : "+ n);
			cash = cash%lst[i];
		}
		sc.close();
	}

}
