package com.sayan;

public class ModiString {
	String str1;
	String str2;
	String str3;
	char ch;

	void getString(String a,String b,String c) {
		str1=a;
		str2=b;
		str3=c;
	}
	
	void channgeStr(char ch2) {
		ch = ch2;
		String modStr1,modStr2,modStr3;
		System.out.println(str1 +" "+str2+" "+str3);
		modStr1 = str1.replace(str1.charAt(0), ch2);
		modStr2 = str2.replace(str2.charAt(0), ch2);
		modStr3 = str3.replace(str3.charAt(0), ch2);
		System.out.println(modStr1 +" "+modStr2+" "+modStr3);
	}
	public static void main(String args[])
	{
		ModiString modiString = new ModiString();
		modiString.getString("Attack on Titan","One Piece","Silent Voice");
		modiString.channgeStr('E');
	}
}
