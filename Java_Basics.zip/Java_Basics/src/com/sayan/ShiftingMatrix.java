package com.sayan;

import java.util.Scanner;

public class ShiftingMatrix {
	int m, n;

	void changingMatrix(int mat1[][],int p,int q) {
		m=p;
		n=q;
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				System.out.print(mat1[i][j] + " ");
			}
			System.out.println();
		}

//		for (int a = 0; a < m; a++) {
//			int temp = mat1[a][3];
//			mat1[a][3] = mat1[a][2];
//			mat1[a][2] = mat1[a][1];
//			mat1[a][1] = mat1[a][0];
//			mat1[a][0] = temp;
//		}
		
		for (int a = 0;a<m;a++)
		{
			int temp = mat1[a][n-1];
			for(int b = n-1;b>0;b--)
			{
				mat1[a][b]=mat1[a][b-1];
			}
			mat1[a][0]=temp;
		}

		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				System.out.print(mat1[i][j] + " ");
			}
			System.out.println();
		}

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		ShiftingMatrix shiftingMatrix = new ShiftingMatrix();
		System.out.println("Enter the range");
		int x = sc.nextInt();
		int y = sc.nextInt();
		int arr[][] = new int[x][y];
		System.out.println("Enter the elements in the array");
		for (int a = 0; a < x; a++) {
			for (int b = 0; b < y; b++) {
				arr[a][b] = sc.nextInt();
			}
		}
		shiftingMatrix.changingMatrix(arr,x,y);
		sc.close();

	}

}
