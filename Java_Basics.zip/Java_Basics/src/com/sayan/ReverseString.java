package com.sayan;
//Program to Reverse a String
import java.util.Scanner;

public class ReverseString {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		String Word = " ", NewWord = " ";
		char ch = ' ';
		int l = 0;
		System.out.println("Enter a String : ");
		Word = sc.nextLine();
		l = Word.length();
		System.out.println(Word);
		for (int i = l - 1; i >= 0; i--) {
			ch = Word.charAt(i);
			NewWord = NewWord + ch;
		}
		System.out.println(NewWord);
		sc.close();
	}
}
