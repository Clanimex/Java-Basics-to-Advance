package com.sayan.class12;

import java.util.Scanner;

public class MYSTIC {
	int n = 0;

	void fillNum(int num) {

		n = num;
	}

	boolean isMystic() {

		int sum = addDigits(n);
		if (sum == 3) {
			return (true);
		} else {
			return (false);
		}
	}

	int addDigits(int num) {
		int s = 0;
		int d = 0;
		do {
			s=0;
			while (num != 0) {
				d = num % 10;
				s = s + d;
				num = num / 10;
			}
			if (s < 10) {
				return s;
			} else {
				num = s;
			}
		} while (num < 10);
		return s;

	}

	public static void main(String[] args) {
		MYSTIC ob = new MYSTIC();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number ");
		int p = sc.nextInt();
		ob.fillNum(p);
		boolean r = ob.isMystic();
		if(r) {
			System.out.println("MYSTIC");
		}
		else {
			System.out.println("Not MYSTIC");
		}

	}

}
