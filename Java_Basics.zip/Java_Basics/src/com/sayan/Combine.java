package com.sayan;

import java.util.Scanner;

public class Combine {
	int com[];
	int size;

	Combine(int nn) {
		size = nn;
		com = new int[size];
	}

	void inputarray() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the array");
		for (int i = 0; i <size; i++) {
			com[i] = sc.nextInt();
		}
		
	}

	void sort() {
		int min = 0;
		for (int i = 0; i < size-1; i++) {
			min = i;
			for (int j = i + 1; j < size; j++) {
				if (com[min] > com[j]) {
					min = j;
				}
			}
			int temp = com[i];
			com[i] = com[min];
			com[min] = temp;
		}
	
	}
	void display()
	{
		for(int i : com)
		{
			System.out.println(i);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Combine co = new Combine(5);
		co.inputarray();
		co.sort();
		co.display();
		
		
	}

}
