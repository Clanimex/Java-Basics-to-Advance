package com.sayan.Collections;

import java.util.HashMap;
import java.util.Scanner;

public class Hashiee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		HashMap<String, Integer> h1 = new HashMap<String, Integer>();
		System.out.println("Enter the range : ");
		int range = sc.nextInt();
		System.out.println("Enter the Values : ");
		for (int i = 1; i <= range; i++) {
			String name1 = sc.next();
			int id = sc.nextInt();
			h1.put(name1, id);
		}
		System.out.println("HashMap Iterations : ");
		for (HashMap.Entry<String , Integer> set: h1.entrySet()) {
			System.out.println(set.getKey() +  " = " + set.getValue());
		}
		
		h1.forEach((key,value)-> System.out.println(key + " = " + value));
		System.out.println("Map elements are : " + h1);
		System.out.println("Only keys : " + h1.keySet());
		System.out.println("Only values : " + h1.values());
		if(h1.containsKey("Sayan"))
		{
			System.out.println("True");
		}
		sc.close();
	}

}
