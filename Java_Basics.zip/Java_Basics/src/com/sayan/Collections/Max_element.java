package com.sayan.Collections;

import java.util.Collections;
import java.util.Scanner;
import java.util.Vector;

public class Max_element {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Vector<Integer> V = new Vector<Integer>();
		System.out.println("Enter the range of the list : ");
		int n = sc.nextInt();
		System.out.println("Enter the Values : ");
		for (int i = 1; i <= n; i++) {
			int num = sc.nextInt();
			V.add(num);
		}
		int max = Collections.max(V);
		int min = Collections.min(V);

		System.out.println("The Max Value from the Vector : " + max);
		System.out.println("The Min Value from the Vector : " + min);
		sc.close();
	}

}
