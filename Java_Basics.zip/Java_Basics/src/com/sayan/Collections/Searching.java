package com.sayan.Collections;

import java.util.Collections;
import java.util.Scanner;
import java.util.Vector;

public class Searching {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range of the Vector : ");
		int r = sc.nextInt();
		Vector<String> V = new Vector<>();
		System.out.println("Enter the elements : ");
		for(int i = 1;i<=r;i++)
		{
			String num = sc.next();
			V.add(num);
		}
		
		Collections.sort(V);
		System.out.println("Vector after Sorting : " + V);
		
		System.out.println("Enter the value to be seached");
		String ser = sc.next();
		int pos = Collections.binarySearch(V, ser);
		if (pos >= 0)
		{	
			String st = V.elementAt(pos);
			System.out.println("The Value is found at position : " + pos + " Value : " + st);
		}
		else 
		{
			System.out.println("The Value is not found");
		}
		sc.close();
	}

}
