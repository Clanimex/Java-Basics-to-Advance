package com.sayan.Collections;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Listsub {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> l1 = new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter te range : ");
		int range = sc.nextInt();
		System.out.println("Enter the elements : ");
		for (int i = 1; i <= range; i++) {
			int num = sc.nextInt();
			l1.add(num);
		}
		System.out.println("The sublist are : ");
		List<Integer> l2 = l1.subList(3, 5);
		System.out.println(l2);
		sc.close();
	}

}
