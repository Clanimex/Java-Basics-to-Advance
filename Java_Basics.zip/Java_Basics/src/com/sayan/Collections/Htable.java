package com.sayan.Collections;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class Htable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Hashtable<Integer, String> h1 = new Hashtable<Integer, String>();
		System.out.println("Enter the range of the the tables : ");
		int range = sc.nextInt();
		for(int i = 0;i<=range;i++) {
			int roll = sc.nextInt();
			String name = sc.nextLine();
			h1.put(roll, name);
		}
		Enumeration e = h1.elements();

		while (e.hasMoreElements()) {
			System.out.println(e.nextElement());
			System.out.println(h1.values());
		}
		
		Set<Integer> st = h1.keySet();
		System.out.println("Set elements : ");
		Iterator<Integer> itr = st.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		sc.close();
	}

}
