package com.sayan.Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Comparing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		List<Integer> l1 = new ArrayList<>();
		System.out.println("Enter the range : ");
		int range = sc.nextInt();
		System.out.println("Enter the elements : ");
		for (int i = 1; i <= range; i++) {
			l1.add(sc.nextInt());
		}
		System.out.println("Original List : " + l1);
		int min = Collections.min(l1);
		int max = Collections.max(l1);
		if (min == max) {
			System.out.println("All elements are equal");
		} else {
			System.out.println("The max and min value are : " + min + max);
		}
		sc.close();
	}

}
