package com.sayan.Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Rotation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range : ");
		int range = sc.nextInt();
		List<Integer> l1 = new ArrayList<>();
		System.out.println("Enter the elements : ");
		for (int i = 1; i <= range;i++)
		{
			int num = sc.nextInt();
			l1.add(num);
		}
		
		System.out.println("List before rotation : " + l1);
//		for(int i = 0;i<4;i++)
//		{
//			int temp = l1.get(0);
//			for(int j = 0;j<6;j++) {
//				l1.set(j, l1.get(j+1));
//			}
//			l1.set(6,temp);
//		}
		Collections.rotate(l1, 4);
		System.out.println("List after rotation : " + l1);
		sc.close();
	}
	
}