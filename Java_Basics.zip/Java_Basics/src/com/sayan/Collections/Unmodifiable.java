package com.sayan.Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Unmodifiable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range : ");
		int range = sc.nextInt();
		List<Integer> l1 = new ArrayList<Integer>();
		System.out.println("Enter the values : ");
		for (int i = 1; i <= range; i++) {
			int n = sc.nextInt();
			l1.add(n);
		}
		System.out.println("Original List : " + l1);
		System.out.println("Enter the positon to be remove : ");
		int p = sc.nextInt();
		l1.remove(p);
		System.out.println("After changing : " + l1);
		
		System.out.println("Before Reverse : " + l1);
		Collections.reverse(l1);
		System.out.println("After Reverse : " + l1);
		
		Collections.shuffle(l1,new Random());
		System.out.println("Shuffling the list randomly : " + l1);
		l1 = Collections.unmodifiableList(l1);
		
		int sz = l1.size();
		System.out.println("The size of the array :  " + sz);
		try {

			l1.remove(range - 1);
		} catch (UnsupportedOperationException e) {
			// TODO: handle exception
			System.out.println("Exception is " + e);
		} finally {
			System.out.println(l1.get(2));
			System.out.println("List changes to ReadOnly");

		}
		sc.close();

	}

}
