package com.sayan.Collections;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class Reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter the range of the List : ");
		int range = sc.nextInt();
		List<Integer> l1 = new ArrayList<Integer>();
		System.out.println("Enter the values");
		for(int i = 1;i<=range;i++)
		{
			int val = sc.nextInt();
			l1.add(val);
		}
		
		ListIterator<Integer> li =  l1.listIterator();
		
		System.out.println("Original list : ");
		while(li.hasNext())
		{
			System.out.print(li.next() + " ");
		}
		System.out.println();
		System.out.println("Reversed list : ");
		while(li.hasPrevious())
		{
			System.out.print(li.previous() + " ");
		}
		sc.close();
	}

}
