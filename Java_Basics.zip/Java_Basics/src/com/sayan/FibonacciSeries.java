package com.sayan;

import java.util.Scanner;

public class FibonacciSeries {
	void fib(int a, int b,int ran) {
		System.out.println("SERIES : ");
		int n = 1;
		System.out.println(a);
		System.out.println(b);
		while (n <= ran-2) {
			int c = a + b;
			System.out.println(c);
			a = b;
			b = c;
			n++;
		}
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first and second number of the series: ");
		int x = sc.nextInt();
		int y = sc.nextInt();
		System.out.println("Enter the range of the series");
		int range = sc.nextInt();
		FibonacciSeries fibonacciSeries = new FibonacciSeries();
		fibonacciSeries.fib(x, y, range);
		sc.close();
	}

}
