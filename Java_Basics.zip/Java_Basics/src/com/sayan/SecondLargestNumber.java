package com.sayan;

public class SecondLargestNumber {
	public static void main(String args[])
	{
		int max = 0, max2 =0;
		int l1[]= {4,6,8,2,0,3,0};		
		for(int i : l1)
		{
			if(i>max)
			{
				max2=max;
				max=i;
			}
			else if(i>max2 && i!=max) {
				max2=i;
			}
		}
		System.out.println(max2);
	}

}
