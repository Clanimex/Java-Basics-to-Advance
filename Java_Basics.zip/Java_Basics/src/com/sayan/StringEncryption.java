package com.sayan;

import java.util.Scanner;

public class StringEncryption {
	void replace(String word) {
		int l = word.length();
		char ch = ' ';
		String newWord = " ";

		for (int i = 0; i < l; i++) {
			ch = word.charAt(i);
			int n = (int) ch + 2;
			newWord = newWord + (char) n;
		}
		System.out.println(word);
		System.out.println(newWord);
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		String st = " ";
		System.out.println("Enter your Word");
		st = sc.nextLine();
		StringEncryption stringEncryption = new StringEncryption();
		stringEncryption.replace(st);
		sc.close();
	}

}
