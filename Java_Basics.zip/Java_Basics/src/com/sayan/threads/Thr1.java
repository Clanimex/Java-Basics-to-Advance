package com.sayan.threads;

public class Thr1 extends Thread {

	public void run() {
//		System.out.println("THR1 RUNNING");
		for (int i = 1; i < 5; i++) {
			try {
				sleep(5);
				System.out.println("Tread test run : " + currentThread().getName());
			} catch (InterruptedException e) {
				System.out.println(e);
				{
					System.out.println(e);
				}
				System.out.println(i);
			}
		}
	}

	public static void main(String args[]) {
		Thr1 t1 = new Thr1();
		Thr1 t2 = new Thr1();
		Thr1 t3 = new Thr1();
		
		t1.start();
		t2.start();
		
		t2.suspend();
		
		t3.start();
		
	}

}
