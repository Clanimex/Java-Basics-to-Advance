package com.sayan.threads;

public class MainSam {
	public static void main(String args[]) {
		Sam1 sm1 = new Sam1();
		Sam2 sm2 = new Sam2();
		
		Thread t1 = new Thread(sm1);
		Thread t2 = new Thread(sm2);
		
		t1.start();
		t2.start();
	}
}
