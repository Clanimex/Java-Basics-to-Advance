package com.sayan.threads;

public class Sam2 implements Runnable{
	public void run()
	{
		for(int i = 0;i<5;i++) {
			System.out.println("Sam 2 is running....");
			try {
				Thread.sleep(1000);
			}
			catch(Exception e) {
				
			}
		}
	}
}
