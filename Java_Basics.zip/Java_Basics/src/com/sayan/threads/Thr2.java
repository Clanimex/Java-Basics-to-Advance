package com.sayan.threads;

public class Thr2 extends Thread{
	public void run()
	{
		System.out.println("Thr2 is running...");
	}
}
