package com.sayan.threads;

public class Sam1 implements Runnable{
	public void run()
	{
		for(int i = 0;i<5;i++) {
			System.out.println("Sam 1 running....");
			try {
				Thread.sleep(1000);
			}
			catch(Exception e) {
				
			}
		}
		
	}
}
