package com.sayan.threads;

public class MainC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thr1 th1 = new Thr1();
		Thr2 th2 = new Thr2();
		th1.start();
		th2.start();
	}

}
