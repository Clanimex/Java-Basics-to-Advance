package Inheritance;

public class MainClass {
	public static void main(String args[]) {
		Animal a = new Cat();
		a.food();
		
		Cat c = new Cat();
		c.food();
		c.food(570);
	}	
}
