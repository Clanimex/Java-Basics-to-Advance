package Inheritance;

public class Animal {

	void food() {
		System.out.println("FOOD type for Cats");
	}
}



