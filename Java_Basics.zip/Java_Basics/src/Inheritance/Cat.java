package Inheritance;

public class Cat extends Animal{
		void food(int x) {
			System.out.println("Fish");
		}
	}
